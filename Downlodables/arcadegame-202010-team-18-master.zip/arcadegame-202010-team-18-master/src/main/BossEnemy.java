package main;

import java.awt.Graphics;

public class BossEnemy extends RangeEnemy {

	private int livesLeft;
	public BossEnemy(int xPos, int yPos, int enemyType) {
		super(xPos, yPos, enemyType);
		this.getHitbox().height = 70;
		this.getHitbox().width = 70;
		this.livesLeft = 100;
	}
	
	@Override
	public void rPattern(Graphics g) {
		super.update(g, (int) (Math.random() * 3) - 1, (int) (Math.random() * 3) - 1);
		if ((int) (Math.random() * 5) == 0) {
			fireBullet((int) (Math.random() * 20) - 10, (int) (Math.random() * 20) - 10);
		}
	}
	
	@Override
	public void setToRemove() {
		if(livesLeft <= 0) {
			super.setToRemove();
		}else {
			livesLeft --;
		}
	}
}
