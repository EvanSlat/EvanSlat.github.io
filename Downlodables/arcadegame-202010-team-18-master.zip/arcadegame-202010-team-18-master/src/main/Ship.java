package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Line2D;
import java.awt.geom.Line2D.Double;
import java.io.File;
import java.io.IOException;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Ship extends Entity {

	
	private final int[] X_FUEL_POSITIONS = {50,150,250,550,650};
	private Fuel fuel;
	private boolean spawningFuel;
	private int fuelCollected;
	private Image rocket;
	private ArrayList<ShipPart> shipParts;
	private boolean playerInShip;

	private final Line2D line = new  Double(345,0,345,610);
	
	/**
	 * handles colectibles and is the main ship
	 * @param xPos
	 * @param yPos
	 */
	public Ship(int xPos, int yPos) {
		super(xPos, yPos, 50, 150, false);
		//System.out.println(this.hitBox);
		this.fuelCollected = 0;
		this.fuel = new Fuel(750, 0);
		this.shipParts = new ArrayList<>();
		this.spawningFuel = false;
		this.playerInShip = false;
		try {
			rocket=ImageIO.read(new File("src/images/rocket.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * move the ship to a desired location
	 * @param xPos
	 * @param yPos
	 */
	public void placeShip(int xPos, int yPos) {
		//System.out.println(hitBox);
		setX(xPos);
		setY(yPos);
		//System.out.println(hitBox);
	}
	
	@Override
	public void drawOn(Graphics g) {
		g.drawImage(rocket, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
		fuel.drawOn(g);
		for(ShipPart p: shipParts) {
			p.drawOn(g);
		}
	}
	
	@Override
	public Color getColor() {
		return Color.PINK;
	}
	
	@Override
	public void update(Graphics g) {
		super.update(g);
		fuel.update(g);
		for(ShipPart p: shipParts) {
			p.update(g);
		}
		if(shipParts.size() > 0) {
			ArrayList<ShipPart> partsToRemove = new ArrayList<>();
			for(ShipPart p: shipParts) {
				if(p.shouldRemove()) {
					partsToRemove.add(p);
				}
			}
			
			for(ShipPart p: partsToRemove) {
				shipParts.remove(p);
			}
		}else {
			if(this.spawningFuel == false) {
				spawnFuel();
				this.spawningFuel = true;
			}
		}
	}
	
	/**
	 * respowns the fuels in a randome location at the top of the screen
	 */
	public void spawnFuel() {
		fuel.respawn(X_FUEL_POSITIONS[(int)(Math.random()*5)]);
	}
	
	/**
	 * spawn in the ship parts at pre determind lications
	 * @param xPos
	 * @param yPos
	 */
	public void spawnShipParts(int xPos, int yPos) {
		shipParts.add(new ShipPart(xPos, yPos));
		getHitbox().height -=50;
		setY(getY()+50);
	}
	
	/**
	 * 
	 * @return fuel
	 */
	public Fuel getFuel() {
		return this.fuel;
	}
	
	/**
	 * 
	 * @return shipParts
	 */
	public ArrayList<ShipPart> getShipParts(){
		return this.shipParts;
	}
	
	/**
	 * handles fuel being collected
	 */
	public void colectFuel() {
		fuelCollected ++;
		spawnFuel();
	}
	
	/**
	 * 
	 * @return fuelCollected
	 */
	public int getFuelCollected() {
		return this.fuelCollected;
	}
	
	/**
	 * handles ship parts being collected 
	 * @param part the part being collectd
	 */
	public void colectShipPart(ShipPart part) {
		part.setToRemove();
		getHitbox().height +=50;
		setY(getY()-50);
	}
	
	/**
	 * clears all parts that are on the screen
	 */
	public void clearParts() {
		fuel.respawn(770);
		shipParts.clear();
		this.spawningFuel = false;
		this.fuelCollected = 0;
		
		getHitbox().height = 150;
	}
	
	/**
	 * level end transition for ship blasting off
	 * @param g
	 */
	public void blastOff(Graphics g) {
		fuel.respawn(770);
		if(Math.abs(getY())%20 < 10) {
			this.update(g, 5, -10);			
		}else {
			this.update(g, -5, -10);
		}
	}

	public void playerTouchShip(boolean t) {
		this.playerInShip = t;
	}
	
	public boolean getPlayerInShip() {
		return this.playerInShip;
	}
}
