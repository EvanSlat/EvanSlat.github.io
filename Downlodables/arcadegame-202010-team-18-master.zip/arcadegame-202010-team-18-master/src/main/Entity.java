package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

/**
 * This will hold the basic propertys for any compenent that the player will
 * interact with
 * 
 * @author slatere
 *
 */
public abstract class Entity extends JComponent {

	protected int xPos;
	protected int yPos;
	protected Rectangle2D.Double hitBox;

	// offset needed to aline hitbox with drawbox
	private final int X_OFFSET = 10;
	private final int Y_OFFSET = 40;

	// the gravity affecting variables
	private boolean hasGravity;
	private final int MAX_GRAVITY = 10;
	private final double ACCELORATION = 0.5;
	private double currentFallSpeed;
	
	//for removal
	private boolean shouldRemove;

	/**
	 * 
	 * @param xPos    starting x position
	 * @param yPos    starting y position
	 * @param gravity is this entity affected by gravity
	 */
	public Entity(int xPos, int yPos,int xhitbox, int yhitbox, boolean hasGravity) {
		this.xPos = xPos;
		this.yPos = yPos;
		this.hasGravity = hasGravity;
		this.currentFallSpeed = 0;
		this.hitBox = new Rectangle2D.Double(xPos, yPos,xhitbox , yhitbox);
		this.shouldRemove = false;
	}

	/**
	 * 
	 * @param g
	 */
	public void drawOn(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(getColor());
		g2.fill(hitBox);
	}

	/**
	 * 
	 * @return this objects color 
	 */
	public abstract Color getColor();
	/**
	 * 
	 * @param e the entity to check with
	 * @return true if the hitboxes of e and this are intersecting
	 */
	public boolean collidesWith(Rectangle2D r) {
		return hitBox.intersects(r);
		
	}
	
	public boolean collidesWith(Entity e) {
		return hitBox.intersects(e.getHitbox());
	}


	/**
	 * move this shape over a cirtan amount
	 * 
	 * @param x amount x to move
	 * @param y amount y to move
	 */
	public void move(int x, int y) {
		this.xPos += x;
		this.yPos += y;
		this.hitBox.x += x;
		this.hitBox.y += y;
	}

	
	public void gravitationalAffect() {
		this.move(0, (int)currentFallSpeed);
		if(currentFallSpeed < MAX_GRAVITY) {
			currentFallSpeed += ACCELORATION;
		}
	}
	/**
	 * @return top left X Position
	 */
	public int getX() {
		return this.xPos;
	}

	public void setX(int x) {
		this.xPos = x;
		this.hitBox.x = x;
	}
	
	/**
	 * @return top left Y Position
	 */
	public int getY() {
		return this.yPos;
	}
	
	public void setY(int y) {
		this.yPos = y;
		this.hitBox.y = y;
	}
	/**
	 * @return the hitbox
	 */
	public Rectangle2D.Double getHitbox() {
		return hitBox;
	}
	
	public double getFallSpeed() {
		return this.currentFallSpeed;
	}
	
	public void resetFallSpeed() {
		this.currentFallSpeed = 0;
	}
	
	public void update(Graphics g,int x, int y) {
		g.clearRect(xPos + X_OFFSET, yPos + Y_OFFSET, (int)Math.round(hitBox.width),(int)Math.round(hitBox.height) );
		move(x, y);
	}
	
	@Override
	public void update(Graphics g) {
		super.update(g);
		g.clearRect(xPos + X_OFFSET, yPos + Y_OFFSET, (int)Math.round(hitBox.width),(int)Math.round(hitBox.height) );
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		drawOn(g);
	}
	
	public void setToRemove() {
		this.shouldRemove = true;
	}
	
	public boolean shouldRemove() {
		return this.shouldRemove;
	}
}
