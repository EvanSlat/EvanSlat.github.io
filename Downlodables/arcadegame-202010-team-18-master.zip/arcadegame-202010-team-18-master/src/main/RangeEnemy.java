package main;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.imageio.ImageIO;

public class RangeEnemy extends MeleEnemy {

	private ArrayList<EnemyBullet> bullets;
	private Image monster;
	private final int fireInterval = 150;

	/**
	 * 
	 * @param xPos top left starting x position
	 * @param yPos top left starting y position
	 * @param id   enemy's unique Id number
	 * @param eH   the enemy handler that this came from
	 */
	public RangeEnemy(int xPos, int yPos, int enemyType) {
		super(xPos, yPos, enemyType);
		this.bullets = new ArrayList<>();
		rPatternSetup();
		try {
			monster=ImageIO.read(new File("src/images/range.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void drawOn(Graphics g) {
		g.drawImage(monster, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
		for (EnemyBullet b : bullets) {
			b.drawOn(g);
		}
	}

	/**
	 * update this game component
	 */
	public void update(Graphics g) {
		rPattern(g);
		for (EnemyBullet b : bullets) {
			b.update(g);
		}

		// removing bullets
		ArrayList<EnemyBullet> bulletsToRemove = new ArrayList<>();
		for (EnemyBullet b : bullets) {
			if (b.shouldRemove()) {
				bulletsToRemove.add(b);
			}
		}

		for (EnemyBullet b : bulletsToRemove) {
			bullets.remove(b);
		}

	}

	/**
	 * fires a new bullet
	 * 
	 * @param xVal
	 * @param yVal
	 */
	public void fireBullet(int xVal, int yVal) {
		this.bullets.add(new EnemyBullet(getX(), getY(), xVal, yVal, this));
	}

	/**
	 * clears the bullets
	 */
	public void clearBullets() {
		this.bullets.clear();
	}

	/**
	 * sets up the ranged enemy to move in the predetermind pattern
	 */
	private void rPatternSetup() {
		// start type 1
		if (this.enemyType == 1) {
			this.xVal = 10;
			this.yVal = 0;
		} // end type 1
		
		//start type 2
		if(this.enemyType == 2) {
			this.xVal = 0;
			this.yVal = 0;
		}
	}

	/**
	 * this will have the ranged enemy move in a predetermind patten
	 * 
	 * @param g
	 */
	public void rPattern(Graphics g) {
		// start type 1
		if (this.enemyType == 1) {
			if (getX() <= 0 || getX() >= 740) {
				xVal = xVal * -1;
			}
			super.update(g, xVal, yVal);
			if (getX() % fireInterval < 4) {
				fireBullet(0, xVal);
			}
		} // end type 1
	}

	/**
	 * 
	 * @return bullets
	 */
	public ArrayList<EnemyBullet> getBullets() {
		return this.bullets;
	}
}
