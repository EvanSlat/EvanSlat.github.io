package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Collectables extends MeleEnemy {

	private boolean collected;
	private Image coin;
	public Collectables(int xPos, int yPos) {
		super(xPos, yPos, 0);
		this.collected = true;
		cPatternSetup();
		try {
			coin=ImageIO.read(new File("src/images/collectable.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void drawOn(Graphics g) {
		g.drawImage(coin, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
	}
	private void cPatternSetup() {
		// start type collectalbe
		this.xVal = 0;
		this.yVal = 5;
		// end type collectable
	}

	// set to be bouncing off the ceeling or floor
	public void wallCelingBounce() {
		this.yVal = 0;
	}

	@Override
	public void update(Graphics g) {
		super.update(g);
	}
	public Color getColor() {
		return Color.ORANGE;
	}
	public boolean getCollected() {
		return this.collected;
	}
	
	public void setCollected(boolean collected) {
		this.collected = collected;
	}
	
	public void moveOffScreen() {
		setX(770);
		setY(0);
	}
}
