package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.sun.javafx.application.PlatformImpl;

public class Player extends Entity {

	private ArrayList<PlayerBullet> bullets;
	private boolean isFireing;
	private static final  int INVINCIBINITY_TIME = 50;
	private int invincibinityTimer;
	private boolean liveOrDead;
	
	private int speed = 10;
	private int hMotion;
	private int vMotion;
	private int facing;
	private Image spaceman;
	private Image spacemanInvincable;
	private boolean reboundLeft;
	private boolean reboundRight;
	private boolean reboundY;
	private int deathTimer;
	private int respawnX;
	private int respawnY;
	private int lives;

	/**
	 * this creates a player that the user can control
	 * 
	 * @param x starting top left x position
	 * @param y starting top left x position
	 */
	public Player(int x, int y) {
		super(x, y, 50, 70, false);
		this.bullets = new ArrayList<>();
		this.isFireing = false;
		this.facing = 1;
		this.invincibinityTimer = 150;
		this.liveOrDead = true;
		this.deathTimer = 0;
		this.respawnX = x;
		this.respawnY = y;
		this.lives = 3;
		try {
			spaceman=ImageIO.read(new File("src/images/spaceman.jpg"));
			spacemanInvincable = ImageIO.read(new File("src/images/spaceman Invincable .jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void update(Graphics g) {
		if(liveOrDead) {
			super.update(g, speed * hMotion, speed * vMotion);
			//count down the invincibility timer
			if(invincibinityTimer > 0) {
				invincibinityTimer --;
			}
			//updateing the bullets
			if(isFireing) {
				fireBullet();
			}

			gravitationalAffect();
			
			//platform collishioin
			if(reboundLeft && hMotion == 1) {
				//System.out.println("Rebound x");
				move(speed*-1,0);
				this.reboundLeft = false;
			}
			
			if(reboundRight && hMotion == -1) {
				//System.out.println("Rebound x");
				move(speed,0);
				this.reboundRight = false;
			}
			
			if(reboundY) {
				//System.out.println("Rebound y");
				move(0,speed*-1*vMotion);	
				this.reboundY = false;
				
			}
			
			//do when dead
		}else {
			if(deathTimer < 90) {
				deathAnimation(g);
			}else {
				deathTimer = 0;
				liveOrDead= true;
				respawn(g);
			}
		}
			
		ArrayList<PlayerBullet> bulletsToRemove = new ArrayList<>();
		for (PlayerBullet b : bullets) {
			b.update(g);
			if(b.shouldRemove()){
				bulletsToRemove.add(b);
			}
		}

		for(PlayerBullet i: bulletsToRemove) {
			bullets.remove(i);
		}
		if(vMotion == -1) {
			resetFallSpeed();
		}

	}

	@Override
	public void drawOn(Graphics g) {
		if(invincibinityTimer > 0) {
			g.drawImage(spacemanInvincable, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
		}else {
			g.drawImage(spaceman, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
		}
		for (PlayerBullet b : bullets) {
			b.drawOn(g);
		}
	}

	@Override
	public Color getColor() {
		if(invincibinityTimer%2 == 1) {
			return Color.CYAN;
		}
		return Color.BLUE;
	}

	/**
	 * set the horizontal direction the player is moving
	 * 
	 * @param h 0:stopped 1:right -1:left
	 */
	public void setHMotion(int h) {
		this.hMotion = h;
		if(h != 0) {
			this.facing = h;
		}
	}

	/**
	 * set the vertical direction the player is moving
	 * 
	 * @param v 0:stopped 1:right -1:left
	 */
	public void setVMotion(int v) {
		this.vMotion = v;
	}

	/**
	 * move the player to a specific lovation on the screen
	 * 
	 * @param x top left x position
	 * @param y top left y position
	 */
	public void setXY(int x, int y) {
		setX(x);
		setY(y);
		this.respawnX = x;
		this.respawnY = y;
	}

	/**
	 * this is the call to see if this is touching any of the platforms 
	 * @param rL reboundLeft
	 * @param rR reboundRight
	 * @param yVel reboundDown
	 * @param falling does gravity apply
	 */
	public void bounceOffPlatforms(boolean rL, boolean rR, boolean yVel, boolean falling){
		this.reboundLeft = rL || this.reboundLeft;
		this.reboundRight = rR || this.reboundRight;
		this.reboundY = yVel || this.reboundY;
		if(!falling) {
			resetFallSpeed();
		}
		
	}
	
	/**
	 * this will fire a new bullet
	 */
	public void fireBullet() {
		bullets.add(new PlayerBullet(getX()+10, getY()+34,this,facing));
	}

	/**
	 * set to be firing or not
	 * @param fire
	 */
	public void setFiring(boolean fire) {
		this.isFireing = fire;
	}
	
	public void clearBullets() {
		bullets.clear();
	}
	
	/**
	 * 
	 * @return bullets
	 */
	public ArrayList<PlayerBullet> getBullets(){
		return this.bullets;
	}
	
	/**
	 * sets the player to be invincible
	 */
	public void goInvincible() {
		this.invincibinityTimer = INVINCIBINITY_TIME;
	}
	
	public boolean isInvincibl() {
		return invincibinityTimer > 0;
	}

	public void respawn(Graphics g) {
		setXY(respawnX, respawnY);
		goInvincible();
		lives--;
		g.clearRect(0, 0, 720, 640);
		
	}

	public void deathAnimation(Graphics g) {
		deathTimer++;
		if(getX()%10 < 5) {
			super.update(g, -5, 0);
		}else {			
			super.update(g, 5, 0);
		}
		
	}

	public void isDead(Graphics g) {
		this.liveOrDead = false;
		clearBullets();
		g.clearRect(0, 0, 720, 640);
		
	}

	public int getLives() {
		return this.lives;
	}
	
}

