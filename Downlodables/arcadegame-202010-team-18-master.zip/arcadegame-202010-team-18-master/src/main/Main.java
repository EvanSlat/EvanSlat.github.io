package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerListener;
import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * The main class for your arcade game.
 * 
 * You can design your game any way you like, but make the game start by running
 * main here.
 * 
 * Also don't forget to write javadocs for your classes and functions!
 * 
 * @author Prescott and Evan Slater
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Cool arcade game");

		System.out.println("Created by");

		System.out.println("Prescott Brackett and Evan Slater");

		new Main();

	}

	private EnemyHandler eH;
	private Player p;
	private Level l;
	private JFrame frame;
	private JPanel panel;

	public Main() {
		frame = new JFrame();
		frame.setSize(new Dimension(720, 640));

		panel = new JPanel();
		frame.add(panel, BorderLayout.NORTH);

		// DO NOT REMOVE THIS
		p = new Player(0, 0);
		// DO NOT REMOVE THIS

		eH = new EnemyHandler();

		frame.setBackground(new Color(0).black);

		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// loading in the inital level
		l = new Level("src/levels", p, eH,frame.getGraphics(),panel);
		try {
			l.loadLevel(1);
			l.initalDrawOn(frame.getGraphics());
		} catch (FileNotFoundException e) {

		}
		// THIS NEEDS A PLAYER AND A LEVEL OBJECT
		frame.addKeyListener(new ButtonListner(p, l));

		// the tickspeed timer for the game
		Timer timer = new Timer(1000 / 30, new ActionListener() {
			private Graphics g = frame.getGraphics();
			@Override
			public void actionPerformed(ActionEvent e) {
				eH.update(g);
				l.update(g);
				p.update(g);
				l.drawOn(g);
			}
		});

		timer.start();

	}
}