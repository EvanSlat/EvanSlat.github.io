package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class PlayerBullet extends Entity {

	private final int xVel = 30;
	private int direction;
	private double lifeTime;
	private Player p;

	/**
	 * 
	 * @param xPos starting top left x position
	 * @param yPos starting top left y position
	 */
	public PlayerBullet(int xPos, int yPos, Player p, int direction) {
		super(xPos, yPos, 30, 2, false);
		this.lifeTime = 100;
		this.p = p;
		this.direction = direction;
	}

	/**
	 * 
	 */
	public void update(Graphics g) {
		super.update(g, xVel * direction, 0);
		this.lifeTime--;
		if (this.lifeTime <= 0) {
			setToRemove();
		}
	}

	@Override
	public Color getColor() {
		return Color.YELLOW;
	}
}
