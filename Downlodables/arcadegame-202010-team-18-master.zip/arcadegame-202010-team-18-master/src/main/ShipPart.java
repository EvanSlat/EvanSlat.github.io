package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ShipPart extends Fuel{

	private Image rocket;
	public ShipPart(int xPos, int yPos) {
		super(xPos, yPos);
		getHitbox().height = 50;
		getHitbox().width = 50;
		try {
			rocket=ImageIO.read(new File("src/images/rocket.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	public void drawOn(Graphics g) {
		g.drawImage(rocket, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
	}
	@Override
	public Color getColor() {
		return Color.PINK;
	}
}
