package main;

import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class EnemyHandler {
	private ArrayList<MeleEnemy> meleEnemys;
	private ArrayList<RangeEnemy> rangedEnemys;
	private Collectables collectable;
	private int spawnNumber;
	private int spawnTimer;
	private final int SPAWN_DELAY = 100;
	private int level;
	private final int[] X_SPAWN_POINTS = {10,650};
	private final int[] Y_SPAWN_POINTS = {100,200,300,400,500};
	
	private int spawnTimerCollectible;
	private int spawnDelayColectibles;
	/**
	 * this will handle the enemys and their calls 
	 */
	public EnemyHandler() {
		this.meleEnemys = new ArrayList<>();
		this.rangedEnemys = new ArrayList<>();
		this.spawnNumber = 0;
		this.spawnTimer = 0;
		this.level=1;
		this.collectable = new Collectables(750, 0);
		this.spawnTimerCollectible = 0;
		this.spawnDelayColectibles = (int)(Math.random()*100)+200;
	}
	//bumps the level up
	public void levelUp() {
		level=level+1;
		if(level > 4) {
			level = 1;
		}
	}
	//bumps the level down
	public void levelDown() {
		level=level-1;
		if(level <= 0) {
			level = 4;
		}
	}
	/**
	 * update all the enemys
	 * 
	 * @param g graphic the enemy is drawn on
	 */
	public void update(Graphics g) {
		ArrayList<MeleEnemy> enemys = new ArrayList<>();
		enemys.addAll(meleEnemys);
		enemys.addAll(rangedEnemys);
		enemys.add(collectable);
		spawnTimer++;
		if(spawnTimer >= SPAWN_DELAY && spawnNumber > 0) {
			//respawn the correct type of enemy for the level
			if(level % 2 == 1) {
				addMeleEnemy(X_SPAWN_POINTS[(int)(Math.random()*2)], Y_SPAWN_POINTS[(int)(Math.random()*5)]);
			}else if(level % 4 == 2){
				addRangedEnemy(X_SPAWN_POINTS[(int)(Math.random()*2)], Y_SPAWN_POINTS[(int)(Math.random()*5)]);
			}
			spawnTimer = 0; 
			spawnNumber--;
		}
		
		//respawns the colectibles
		if(collectable.getCollected()) {
			spawnTimerCollectible++;
		}
		if(spawnTimerCollectible >= spawnDelayColectibles) {
			this.spawnDelayColectibles = (int)(Math.random()*100)+200;
			spawnTimerCollectible = 0;
			Random rand=new Random();
			addCollectable(rand.nextInt(700),60);
		}
	
		for (MeleEnemy e: enemys) {
			e.update(g);
		}
		collectable.update(g);
		
		//removing enemys 
		ArrayList<MeleEnemy> enemysToRemove = new ArrayList<>();
		for(MeleEnemy e: enemys) {
			if(e.shouldRemove()) {
				enemysToRemove.add(e);
			}
		}
		for(MeleEnemy e: enemysToRemove) {
			meleEnemys.remove(e);
			rangedEnemys.remove(e);
			spawnNumber++;
		}
		if(collectable.getCollected()) {
			collectable.moveOffScreen();
			collectable.setCollected(true);
		}
	}

	/**
	 * draw all the enemys
	 * 
	 * @param g graphic the enemy is drawn on
	 */
	public void drawOn(Graphics g) {
		ArrayList<MeleEnemy> enemys = new ArrayList<>();
		enemys.addAll(meleEnemys);
		enemys.addAll(rangedEnemys);
		for (MeleEnemy e : enemys) {
			e.drawOn(g);
		}
		collectable.drawOn(g);
	}

	/**
	 * add a new mele enemy to the screen
	 * 
	 * @param x starting position
	 * @param y starting position
	 */
	public void addMeleEnemy(int x, int y) {
		if((level+1)/2 % 2 == 1) {
			meleEnemys.add(new MeleEnemy(x, y, 1));
		}else {
			meleEnemys.add(new MeleEnemy(x, y, 2));
		}
	}

	/**
	 * add a new ranged enemy to the screen
	 * 
	 * @param x starting position
	 * @param y starting position
	 */
	public void addRangedEnemy(int x, int y) {
		if((level/2) % 2 == 1) {
			rangedEnemys.add(new RangeEnemy(x, y, 1));
		}else {
			rangedEnemys.add(new BossEnemy(x, y, 2));
			//rangedEnemys.add(new RangeEnemy(x, y, 2));
		}
	}
	
	/**
	 * add a new collectable to the screen
	 * 
	 * @param x starting position
	 * @param y starting position
	 */
	public void addCollectable(int x, int y) {
		collectable.setX(x);
		collectable.setY(y);
		collectable.yVal = 5;
		collectable.setCollected(false);
	}
	
	/**
	 * removes all the enemys 
	 */
	public void removeAllEnemys() {
		meleEnemys.clear();
		rangedEnemys.clear();
		collectable.moveOffScreen();
		spawnNumber = 0;
	}

	
	/**
	 * 
	 * @return meleEnemys
	 */
	public ArrayList<MeleEnemy> getMeleEnemys(){
		return this.meleEnemys;
	}
	
	/**
	 * 
	 * @return rangedEnemys
	 */
	public ArrayList<RangeEnemy> getRangedEnemys(){
		return this.rangedEnemys;
	}
	
	/**
	 * 
	 * @return collectables
	 */
	public Collectables getCollectable(){
		return this.collectable;
	}
}
