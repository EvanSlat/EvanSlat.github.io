package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.text.StyledEditorKit.AlignmentAction;

public class Level {

	private Color[][] color = new Color[60][70];
	private String levelFile;
	private final int X_OFFSET = 10;
	private final int Y_OFFSET = 40;
	private int currentLevel;
	
	private final Rectangle2D LEFT_WALL = new Rectangle2D.Double(0, 0, 5, 640);
	private final Rectangle2D RIGHT_WALL = new Rectangle2D.Double(690, 0, 720, 640);
	private final Rectangle2D CEILING = new Rectangle2D.Double(0, 0, 720, 20);
	
	private ArrayList<Platform> platforms= new ArrayList<Platform>();
	private Graphics g;
	private Ship ship;
	private EnemyHandler eH;
	private Player player;
	private JPanel scorePanel;
	
	private JLabel scoreArea;
	private int score;
	
	private int blastOffTimer;
	
	/**
	 * 
	 * @param filename file location with all the level files in it 
	 * @param p player
	 * @param eH enemy handler
	 * @param g graphics
	 * @param scorePanel panel
	 */
	public Level(String filename, Player p, EnemyHandler eH,Graphics g, JPanel scorePanel) {
		this.levelFile = filename;
		this.player = p;
		this.eH = eH;
		this.currentLevel = 1;
		this.g = g;
		this.ship = new Ship(0, 0);
		this.score = 0;
		this.scorePanel = scorePanel;
		this.scoreArea = new JLabel(""+score);
		this.scoreArea.setForeground(Color.WHITE);
		this.scorePanel.add(this.scoreArea);
		this.scorePanel.setBackground(Color.BLACK);
		this.blastOffTimer = 0;
	}

	/**
	 * This will load up the levels
	 * @param l the level number to load
	 * @throws FileNotFoundException
	 */
	public void loadLevel(int l) throws FileNotFoundException {
	//	System.out.println(l);
		int lineNumber = 0;
		FileReader file;
		file = new FileReader((levelFile + "/level" + l));
		Scanner scanner = new Scanner(file);
		while (scanner.hasNext()) {
			String line = scanner.nextLine();
			for (int i = 0; i < line.length(); i++) {
				if (line.charAt(i) == '.') {
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == '-') {
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == '_') {
					Platform p = new Platform(i * 10 , lineNumber * 10 );
					//entitys.add(p);
					platforms.add(p);
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == 'P') {
					//entitys.add(new Ship(i * 10 + X_OFFSET, lineNumber * 10 + Y_OFFSET));
					ship.spawnShipParts(i * 10 , lineNumber * 10 );
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == 'M') {
					eH.addMeleEnemy(i * 10 , lineNumber * 10 );
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == 'R') {
					eH.addRangedEnemy(i * 10 , lineNumber * 10 );
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == 'S') {
					//entitys.add(new Ship(i * 10 + X_OFFSET, lineNumber * 10 + Y_OFFSET));
					ship.placeShip(i * 10 , lineNumber * 10 );
					//entitys.add(ship);
					color[lineNumber][i] = Color.BLACK;
				}
				if (line.charAt(i) == 'H') {
					player.setXY(i * 10 , lineNumber * 10 );
					//entitys.add(p);
					color[lineNumber][i] = Color.BLACK;
				}
			}
			lineNumber++;
		}
		scanner.close();
	}

	/**
	 * loads the next level one up
	 * @throws FileNotFoundException
	 */
	public void upLevel() {
		// System.out.println("did i say anything");
		this.currentLevel++;
		clearLevel();
		try {
			eH.levelUp();
			loadLevel(currentLevel);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			eH.levelDown();
			this.currentLevel = 0;
			upLevel();
		}
	}

	/**
	 * loads the prevus level one down
	 * @throws FileNotFoundException
	 */
	public void downLevel() throws FileNotFoundException {
		this.currentLevel--;
		if(this.currentLevel <=0) {
			this.currentLevel = 4;
		}
		clearLevel();
		eH.levelDown();
		loadLevel(currentLevel);
	}
	
	/**
	 * reloads the current level
	 */
	public void reloadCurrentLevel() {
		clearLevel();
		try {
			loadLevel(currentLevel);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * this handles the transition from winning one level to the next
	 * @param g
	 */
	public void levelTransition(Graphics g) {
		eH.removeAllEnemys();
		player.move(800, 0);
		if(blastOffTimer == 1) {
			g.clearRect(0, 0, 720, 640);
		}
		if(blastOffTimer < 90) {
			ship.blastOff(g);
			blastOffTimer ++;
			//System.out.println("test");
		}else {
			blastOffTimer = 0;
			upLevel();
		}
	}

	
	/**
	 * refresh draw on for continues drawling
	 * 
	 * @param g
	 */
	public void drawOn(Graphics g) {
		if(player.getLives()<=0) {
			gameOver();
			
		}
		else {
		g.translate(X_OFFSET, Y_OFFSET);
		player.drawOn(g);
		for(Platform p: platforms) {
			p.drawOn(g);
		}
		eH.drawOn(g);
		ship.drawOn(g);
		scorePanel.repaint();
		g.translate(-X_OFFSET, -Y_OFFSET);
		}
	}

	
	/**
	 * the inital draw on that should add the platforms and backround
	 * 
	 * @param g
	 */
	public void initalDrawOn(Graphics g) {
		g.translate(10, 40);
		for (int i = 0; i < color.length; i++) {
			for (int k = 0; k < color[1].length; k++) {
				g.setColor(color[i][k]);
				g.fillRect(k * 10, i * 10, 10, 10);
			}

		}
		g.translate(-10, -40);
		drawOn(g);
	}

	
	/**
	 * update this game component
	 * detects if there is a level win
	 * @throws FileNotFoundException 
	 */
	public void update(Graphics g) {
		//update to chage it to the next level;
		
		if(ship.getFuelCollected() >= 5 && ship.getPlayerInShip()) {
			levelTransition(g);
		}else {
			allCollishion();
			
			for(Platform p: platforms) {
				p.update(g);
			}
			ship.update(g);
			
			//updating the score
			scoreArea.setText("Score:"+score+" Lives:"+player.getLives()+" Fuel collected:" +ship.getFuelCollected() +" Level:"+currentLevel);
			scorePanel.update(g);
		}
		if(player.getLives() <= 0) {
			gameOver();
		}
	}	
	
	/**
	 * removes all entitys of the level and prepares screen for next level load
	 */
	public void clearLevel() {
		eH.removeAllEnemys();
		platforms.clear();
		ship.clearParts();
		g.clearRect(0, 0, 720, 640);
	}
	
	
	/**
	 * handles collishions and tells objects when they have collidind with other stuff
	 */
	void allCollishion() {
		ArrayList<MeleEnemy> allEnemys = new ArrayList<MeleEnemy>();
		allEnemys.addAll(eH.getMeleEnemys());
		allEnemys.addAll(eH.getRangedEnemys());
		allEnemys.add(eH.getCollectable());
		//player with collectable
		if(player.collidesWith(eH.getCollectable())) {
			eH.getCollectable().setCollected(true);
			score +=200;
		}
		//player with enemy
		for(MeleEnemy e :eH.getMeleEnemys()) {
				if(player.collidesWith(e)) {
					e.setToRemove();
					if(!player.isInvincibl()) {
						player.isDead(g);
					}
					//p.new level
				}//end if
				for(PlayerBullet b : player.getBullets()) {
					if(e.collidesWith(b)) {
						e.setToRemove();
						b.setToRemove();
						score += 50;
					}//end if
				}//end inner for
		}//end for
		
		//plaer with enemy bullet
		for(RangeEnemy e: eH.getRangedEnemys()) {
			if(player.collidesWith(e)) {
				e.clearBullets();
				e.setToRemove();
				if(!player.isInvincibl()) {
					player.isDead(g);
					
				}
			}//end if 
			for(EnemyBullet b :e.getBullets()) {
				if(player.collidesWith(b)) {
					b.setToRemove();
					if(!player.isInvincibl()) {
						player.isDead(g);
					}
				}//end if
			}//end inner for
			for(PlayerBullet b : player.getBullets()) {
				if(e.collidesWith(b)) {
					e.setToRemove();
					b.setToRemove();
					score += 50;
				}//end if
			}//end inner for
		}//end for
		
		//player with platform
		for(Platform p : platforms) {
			boolean top = p.topCollishion(player.getHitbox());
			boolean bottom = p.bottomCollishion(player.getHitbox());
			boolean left = p.leftCollishion(player.getHitbox());
			boolean right = p.rightCollishion(player.getHitbox());
			boolean rL = false;
			boolean rR = false;
			boolean yVel = false;
			boolean falling = true;
			if((top && bottom)) {
				rL = left;
				rR = right;
				//System.out.println("test");
			}
			else if(bottom){
				yVel = true;
				//System.out.println("thisishappeafea fa faf ase fa" );
			}
			else if(top) {
				//System.out.println("should now stand");
				falling = false;
				
			}
			if(!top) {
				//System.out.println("should now fall");
				falling = true;
			}
			//System.out.println(top + " "+ bottom+ " "+falling);
			player.bounceOffPlatforms(rL,rR,yVel,falling);
			//enemy with platform
			for(MeleEnemy e : allEnemys) {
				top = p.topCollishion(e.getHitbox()) || e.collidesWith(CEILING);
				bottom = p.bottomCollishion(e.getHitbox());
				left = p.leftCollishion(e.getHitbox()) || e.collidesWith(LEFT_WALL);
				right = p.rightCollishion(e.getHitbox()) || e.collidesWith(RIGHT_WALL);
				
				if(top || bottom) {
					e.wallCelingBounce();
					//System.out.println("test");
				}
				if(left || right) {					
					e.wallBounce();
				}
			}
		}
		//player colides with the side of the screen
		if(player.collidesWith(LEFT_WALL)) {
			player.bounceOffPlatforms(false, true, false, true);
			//System.out.println("left wall");
		}
		if(player.collidesWith(RIGHT_WALL)) {
			player.bounceOffPlatforms(true, false, false, true);
			//System.out.println("right wall");
		}
		if(player.collidesWith(CEILING)) {
			player.bounceOffPlatforms(false, false, true, true);
		}
		
		
		
		//player with ship part
		for(ShipPart p :ship.getShipParts()) {
			if(player.collidesWith(p)) {
				p.playerHolding(g, player.getX(), player.getY());
			}//end if
			
			if(p.collidesWith(ship)) {
				ship.colectShipPart(p);
				score += 100;
			}
		}//end for
		
		//player with fuel
		if(ship.getFuel().collidesWith(player)) {
			ship.getFuel().playerHolding(g, player.getX(), player.getY());
		}//end if
		if(ship.getFuel().collidesWith(ship)) {
			ship.colectFuel();
			score += 100;
		}
		
		//player colideing with the ship
		ship.playerTouchShip(player.collidesWith(ship));
		
		
		for(Platform p: platforms) {
			//platform with ship part and fuel
			if(p.collidesWith(ship.getFuel())) {
				ship.getFuel().onPlatform();
			}//end if
			for(ShipPart sp: ship.getShipParts()) {
				if(p.collidesWith(sp)) {
					sp.onPlatform();
				}//end uf
			}//end inner for

			
			//enemy with platform
			for(MeleEnemy e :allEnemys) {
				if(p.collidesWith(e)) {
					//enemy hits platform
				}
			}//end inner for
		}//end for	
	
	}
	
	
	private void gameOver() {
		Font font=new Font("Arial",0,80);
		g.setFont(font);
		g.setColor(Color.RED);
		g.drawString("Game Over", 150, 200);
		font = new Font("Arial",0,30);
		g.setFont(font);
		g.drawString("Score "+score, 300, 230);
	}
}
