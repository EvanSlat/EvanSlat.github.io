package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;

public class Platform extends Entity {
	/**
	 * 
	 * @param xPos
	 * @param yPos
	 */
	public Platform(int xPos, int yPos) {
		
		super(xPos, yPos, 200, 20, false);
	}
	
	/**
	 * colishion with the top of this platform 
	 * @param r
	 * @return
	 */
	public boolean topCollishion(Rectangle2D r) {
		int xPos = getX();
		int yPos = getY();
		Rectangle2D.Double hitBox = getHitbox();
		return r.intersectsLine(xPos, yPos, xPos+hitBox.width, yPos);
	}
	public boolean leftCollishion(Rectangle2D r) {
		int xPos = getX();
		int yPos = getY();
		Rectangle2D.Double hitBox = getHitbox();
		return r.intersectsLine(xPos, yPos, xPos, yPos+hitBox.height);
	}
	public boolean rightCollishion(Rectangle2D r) {
		int xPos = getX();
		int yPos = getY();
		Rectangle2D.Double hitBox = getHitbox();
		return r.intersectsLine(xPos+hitBox.width, yPos, xPos+ hitBox.width, yPos+hitBox.height);
	}
	public boolean bottomCollishion(Rectangle2D r) {
		int xPos = getX();
		int yPos = getY();
		Rectangle2D.Double hitBox = getHitbox();
		return r.intersectsLine(xPos, yPos+hitBox.height, xPos+hitBox.width, yPos+hitBox.height);
	}

	@Override
	public Color getColor() {
		return Color.GREEN;
	}
}
