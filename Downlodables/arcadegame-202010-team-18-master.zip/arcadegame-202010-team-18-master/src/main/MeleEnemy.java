package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class MeleEnemy extends Entity {

	protected int xVal;
	protected int yVal;
	private Image monster;
	protected int enemyType;

	private boolean yBounce = false;
	private boolean xBounce = false;

	/**
	 * 
	 * @param xPos top left starting x position
	 * @param yPos top left starting y position
	 */
	public MeleEnemy(int xPos, int yPos, int enemyType) {
		super(xPos, yPos, 30, 30, false);
		this.enemyType = enemyType;
		mPatternSetup();
		//System.out.println(enemyType);
		try {
			monster=ImageIO.read(new File("src/images/mele.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void update(Graphics g) {
		if (xBounce) {
			this.xVal *= -1;
			xBounce = false;
		}

		if (yBounce) {
			this.yVal *= -1;
			yBounce = false;
		}

		super.update(g, xVal, yVal);
	}
	public void drawOn(Graphics g) {
		g.drawImage(monster, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
	}
	/**
	 * update this game component
	 */
	protected void mPatternSetup() {
		// start type 1
		if(enemyType == 1) {
		this.xVal = 10;
		this.yVal = 10;
		}
		// end type 1
		
		//start type 2
		if(enemyType == 2) {
			this.xVal = 15;
			this.yVal = 3;
		}//end type 2
	}

	/**
	 * set to bounce off of a wall
	 */
	public void wallBounce() {
		this.xBounce = true;
	}

	// set to be bouncing off the ceeling or floor
	public void wallCelingBounce() {
		this.yBounce = true;
	}


	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return Color.RED;
	}

}
