package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class EnemyBullet extends Entity {

	private RangeEnemy r;
	private int lifeTime;
	private int xVel;
	private int yVel;
	/**
	 * 
	 * @param xPos starting top left x position
	 * @param yPos starting top left y position
	 */
	public EnemyBullet(int xPos, int yPos,int xVel, int yVel,RangeEnemy r) {
		super(xPos, yPos, 5, 5, false);
		this.r = r;
		this.xVel = xVel;
		this.yVel = yVel;
		lifeTime = 40;
		
	}
	
	@Override
	public void update(Graphics g) {
		super.update(g, xVel, yVel);
		lifeTime--;
		if(lifeTime < 0) {
			setToRemove();
		}
	}

	@Override
	public Color getColor() {
		return Color.MAGENTA;
	}
}
