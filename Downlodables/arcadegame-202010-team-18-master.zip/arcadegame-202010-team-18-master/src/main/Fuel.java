package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D.Double;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Fuel extends Entity {

	//the ship line
	private final Line2D shipLine = new  Double(345,0,345,610);
	
	private boolean colorFlash;
	private Image gasCan;
	private boolean beingCarryed;
	private boolean onPlatform = false;
	/**
	 * 
	 * @param xPos starting top left x position
	 * @param yPos starting top left y position
	 */
	public Fuel(int xPos, int yPos) {
		super(xPos, yPos, 30, 30, true);
		this.colorFlash = true;
		this.beingCarryed = false;
		try {
			gasCan=ImageIO.read(new File("src/images/fuel.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * update this game component
	 */
	public void update(Graphics g) {

			super.update(g,0,0);
			if(!onPlatform) {
				gravitationalAffect();
			}
			onPlatform = false;

	}
	
	public void drawOn(Graphics g) {
		g.drawImage(gasCan, this.xPos, this.yPos, (int)this.hitBox.width, (int)this.hitBox.height, null);
	}
	/**
	 * this will respawn the fuel
	 * @param xPos
	 */
	public void respawn(int xPos) {
		this.setX(xPos);
		this.setY(0);
	}
	
	/**
	 * this is the call for if the player is holdthing this item
	 * @param g
	 * @param xPos players x position
	 * @param yPos player y position
	 */
	public void playerHolding(Graphics g, int xPos,int yPos) {
		if(getHitbox().intersectsLine(shipLine)) {
			update(g,0,0);
		}else {
			super.update(g,xPos,yPos);
			setX(xPos);
			setY(yPos);
		}
	}
	
	/**
	 * call for if this is on a platform
	 */
	public void onPlatform() {
		onPlatform = true;
	}


	@Override
	public Color getColor() {
		if(colorFlash) {
			colorFlash = false;
			return Color.MAGENTA;
		}else {
			colorFlash = true;
			return Color.CYAN;
		}
	}
}
