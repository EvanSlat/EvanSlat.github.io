package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;

/**
 * @author slatere Perpose: To get and return what keys on the keyboard have
 *         been pushed.
 */
public class ButtonListner implements KeyListener {

	private Player p;
	private Level l;

	/**
	 * gets and sends key presses
	 * 
	 * @param p Player
	 * @param l Level
	 */
	public ButtonListner(Player p, Level l) {
		this.p = p;
		this.l = l;
	}

	/**
	 * set the player into motion
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		String key = KeyEvent.getKeyText(e.getKeyCode());
		// System.out.println("pressed: "+key);
		if (key.equals("Up")) {
			p.setVMotion(-1);
		} else if (key.equals("Down")) {
		//	p.setVMotion(1);
		} else if (key.equals("Left")) {
			p.setHMotion(-1);
		} else if (key.equals("Right")) {
			p.setHMotion(1);
		}

	}

	/**
	 * stop player who is in motion
	 */
	@Override
	public void keyReleased(KeyEvent e) {
		String key = KeyEvent.getKeyText(e.getKeyCode());
		// System.out.println("Released: " + key);
		if (key.equals("Up") || key.equals("Down")) {
			p.setVMotion(0);
		} else if (key.equals("Left") || key.equals("Right")) {
			p.setHMotion(0);
		} else if(key.equals("Space")){
			p.setFiring(false);
		}
	}

	/**
	 * change levels and picks up the space
	 */
	@Override
	public void keyTyped(KeyEvent e) {
		char key = Character.toUpperCase(e.getKeyChar());
		// System.out.println("Typed: " + key);
		if (key == 'D') {
			try {
				l.downLevel();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		} else if (key == 'U') {
			try {
				l.upLevel();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
		}else if(key == ' ') {
			p.setFiring(true);
			
		} else if (key == 'Q') {
			System.out.println(p.getHitbox());
			//System.out.println(l.entitys);
		} 
		
		else if(key == 'I') {
			p.goInvincible();
		}
	}

}
