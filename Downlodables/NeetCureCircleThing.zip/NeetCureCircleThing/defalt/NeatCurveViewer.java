package defalt;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.Timer;


public class NeatCurveViewer {

	
	
	/**
	 * The width of the frame.
	 */
	public static final int WIDTH = 800;
	/**
	 * The height of the frame.
	 */
	public static final int HEIGHT = 800;
	
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		JFrame frame = new JFrame();
//get the information to start		
		frame.setTitle("Neet curve");
		InfoComponent i = new InfoComponent();
		i.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		frame.add(i);
		
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				i.reseveKey(e.getKeyChar());
				i.repaint();
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
				
			}
		});

		i.textToDisplay("Input number of points, standerd 2000 : This is how many lines there will be, more means a better quality");
		int points = -1;
		while(points == -1) {
			points = i.getData();
			System.out.print("");
		}
		i.textToDisplay("Input radius, standerd 300 : This is the radius for the circle that is created");
		i.repaint();
		int radius = -1;
		while(radius == -1) {
			radius = i.getData();
		}
		i.textToDisplay("Input starting degree, standerd 1 : This is how far into the pattern it will start at");
		i.repaint();
		int degree = -1;
		while(degree == -1) {
			degree = i.getData();
		}
		
		i.textToDisplay("Input movement speed, standerd 10 : This is how fast the digree will increse the number is divided by 10000");
		i.repaint();
		int speed = -1;
		while(speed == -1) {
			speed = i.getData();
		}
		
		//this now creates the actual art
		CurveComponent c = new CurveComponent(points,radius,degree,speed);
//		System.out.print("Will it be animated(insert a boolean)");
		frame.remove(i);
		c.setPreferredSize(new Dimension(radius*2,radius*2));
		frame.add(c);
		
		frame.pack();
		
		boolean animated = true;
		Timer timer = new Timer(1,new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				c.tick();
				
			}
		});
		if(animated) {
			timer.start();
		}
		keyboard.close();
	}
}
